﻿namespace Siri
{
    partial class BookRead
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.gunaGradientCircleButton1 = new Guna.UI.WinForms.GunaGradientCircleButton();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.gunaGradientCircleButton2 = new Guna.UI.WinForms.GunaGradientCircleButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(33, 61);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(588, 253);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::Siri.Properties.Resources.VpBook1;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(800, 450);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // gunaGradientCircleButton1
            // 
            this.gunaGradientCircleButton1.AnimationHoverSpeed = 0.07F;
            this.gunaGradientCircleButton1.AnimationSpeed = 0.03F;
            this.gunaGradientCircleButton1.BackColor = System.Drawing.Color.White;
            this.gunaGradientCircleButton1.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(230)))), ((int)(((byte)(248)))));
            this.gunaGradientCircleButton1.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(147)))), ((int)(((byte)(230)))));
            this.gunaGradientCircleButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaGradientCircleButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaGradientCircleButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaGradientCircleButton1.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaGradientCircleButton1.ForeColor = System.Drawing.Color.White;
            this.gunaGradientCircleButton1.Image = null;
            this.gunaGradientCircleButton1.ImageSize = new System.Drawing.Size(52, 52);
            this.gunaGradientCircleButton1.Location = new System.Drawing.Point(79, 320);
            this.gunaGradientCircleButton1.Name = "gunaGradientCircleButton1";
            this.gunaGradientCircleButton1.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(145)))), ((int)(((byte)(221)))));
            this.gunaGradientCircleButton1.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(85)))), ((int)(((byte)(255)))));
            this.gunaGradientCircleButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaGradientCircleButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaGradientCircleButton1.OnHoverImage = null;
            this.gunaGradientCircleButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaGradientCircleButton1.Size = new System.Drawing.Size(105, 102);
            this.gunaGradientCircleButton1.TabIndex = 3;
            this.gunaGradientCircleButton1.Text = "Add";
            this.gunaGradientCircleButton1.Click += new System.EventHandler(this.gunaGradientCircleButton1_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // gunaGradientCircleButton2
            // 
            this.gunaGradientCircleButton2.AnimationHoverSpeed = 0.07F;
            this.gunaGradientCircleButton2.AnimationSpeed = 0.03F;
            this.gunaGradientCircleButton2.BackColor = System.Drawing.Color.White;
            this.gunaGradientCircleButton2.BaseColor1 = System.Drawing.Color.SlateBlue;
            this.gunaGradientCircleButton2.BaseColor2 = System.Drawing.Color.Fuchsia;
            this.gunaGradientCircleButton2.BorderColor = System.Drawing.Color.Black;
            this.gunaGradientCircleButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaGradientCircleButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaGradientCircleButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaGradientCircleButton2.ForeColor = System.Drawing.Color.White;
            this.gunaGradientCircleButton2.Image = null;
            this.gunaGradientCircleButton2.ImageSize = new System.Drawing.Size(52, 52);
            this.gunaGradientCircleButton2.Location = new System.Drawing.Point(489, 334);
            this.gunaGradientCircleButton2.Name = "gunaGradientCircleButton2";
            this.gunaGradientCircleButton2.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(145)))), ((int)(((byte)(221)))));
            this.gunaGradientCircleButton2.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(85)))), ((int)(((byte)(255)))));
            this.gunaGradientCircleButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaGradientCircleButton2.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaGradientCircleButton2.OnHoverImage = null;
            this.gunaGradientCircleButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaGradientCircleButton2.Size = new System.Drawing.Size(87, 88);
            this.gunaGradientCircleButton2.TabIndex = 4;
            this.gunaGradientCircleButton2.Text = "gunaGradientCircleButton2";
            this.gunaGradientCircleButton2.Click += new System.EventHandler(this.gunaGradientCircleButton2_Click);
            // 
            // BookRead
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.gunaGradientCircleButton1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.gunaGradientCircleButton2);
            this.Name = "BookRead";
            this.Text = "BookRead";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Guna.UI.WinForms.GunaGradientCircleButton gunaGradientCircleButton1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private Guna.UI.WinForms.GunaGradientCircleButton gunaGradientCircleButton2;
    }
}