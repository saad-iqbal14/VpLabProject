﻿namespace Siri
{
    partial class Intro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Intro));
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.gunaGradientCircleButton1 = new Guna.UI.WinForms.GunaGradientCircleButton();
            this.gunaGradientCircleButton2 = new Guna.UI.WinForms.GunaGradientCircleButton();
            this.gunaGradientPanel1 = new Guna.UI.WinForms.GunaGradientPanel();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(79, 36);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(634, 250);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // gunaGradientCircleButton1
            // 
            this.gunaGradientCircleButton1.AnimationHoverSpeed = 0.07F;
            this.gunaGradientCircleButton1.AnimationSpeed = 0.03F;
            this.gunaGradientCircleButton1.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(230)))), ((int)(((byte)(248)))));
            this.gunaGradientCircleButton1.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(147)))), ((int)(((byte)(230)))));
            this.gunaGradientCircleButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaGradientCircleButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaGradientCircleButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaGradientCircleButton1.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaGradientCircleButton1.ForeColor = System.Drawing.Color.White;
            this.gunaGradientCircleButton1.Image = null;
            this.gunaGradientCircleButton1.ImageSize = new System.Drawing.Size(52, 52);
            this.gunaGradientCircleButton1.Location = new System.Drawing.Point(12, 318);
            this.gunaGradientCircleButton1.Name = "gunaGradientCircleButton1";
            this.gunaGradientCircleButton1.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(145)))), ((int)(((byte)(221)))));
            this.gunaGradientCircleButton1.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(85)))), ((int)(((byte)(255)))));
            this.gunaGradientCircleButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaGradientCircleButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaGradientCircleButton1.OnHoverImage = null;
            this.gunaGradientCircleButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaGradientCircleButton1.Size = new System.Drawing.Size(120, 120);
            this.gunaGradientCircleButton1.TabIndex = 2;
            this.gunaGradientCircleButton1.Text = "Add";
            this.gunaGradientCircleButton1.Click += new System.EventHandler(this.gunaGradientCircleButton1_Click);
            // 
            // gunaGradientCircleButton2
            // 
            this.gunaGradientCircleButton2.AnimationHoverSpeed = 0.07F;
            this.gunaGradientCircleButton2.AnimationSpeed = 0.03F;
            this.gunaGradientCircleButton2.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(147)))), ((int)(((byte)(230)))));
            this.gunaGradientCircleButton2.BaseColor2 = System.Drawing.Color.Gainsboro;
            this.gunaGradientCircleButton2.BorderColor = System.Drawing.Color.Black;
            this.gunaGradientCircleButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaGradientCircleButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaGradientCircleButton2.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaGradientCircleButton2.ForeColor = System.Drawing.Color.White;
            this.gunaGradientCircleButton2.Image = null;
            this.gunaGradientCircleButton2.ImageSize = new System.Drawing.Size(52, 52);
            this.gunaGradientCircleButton2.Location = new System.Drawing.Point(668, 318);
            this.gunaGradientCircleButton2.Name = "gunaGradientCircleButton2";
            this.gunaGradientCircleButton2.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(145)))), ((int)(((byte)(221)))));
            this.gunaGradientCircleButton2.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(85)))), ((int)(((byte)(255)))));
            this.gunaGradientCircleButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaGradientCircleButton2.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaGradientCircleButton2.OnHoverImage = null;
            this.gunaGradientCircleButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaGradientCircleButton2.Size = new System.Drawing.Size(120, 120);
            this.gunaGradientCircleButton2.TabIndex = 3;
            this.gunaGradientCircleButton2.Text = "Speek";
            this.gunaGradientCircleButton2.Click += new System.EventHandler(this.gunaGradientCircleButton2_Click);
            // 
            // gunaGradientPanel1
            // 
            this.gunaGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gunaGradientPanel1.BackgroundImage")));
            this.gunaGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gunaGradientPanel1.GradientColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(227)))), ((int)(((byte)(217)))));
            this.gunaGradientPanel1.GradientColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(230)))), ((int)(((byte)(248)))));
            this.gunaGradientPanel1.GradientColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(147)))), ((int)(((byte)(230)))));
            this.gunaGradientPanel1.GradientColor4 = System.Drawing.SystemColors.ActiveCaptionText;
            this.gunaGradientPanel1.Location = new System.Drawing.Point(-2, -10);
            this.gunaGradientPanel1.Name = "gunaGradientPanel1";
            this.gunaGradientPanel1.Size = new System.Drawing.Size(804, 322);
            this.gunaGradientPanel1.TabIndex = 4;
            this.gunaGradientPanel1.Text = "gunaGradientPanel1";
            // 
            // Intro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.gunaGradientCircleButton2);
            this.Controls.Add(this.gunaGradientCircleButton1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.gunaGradientPanel1);
            this.Name = "Intro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Intro";
            this.Load += new System.EventHandler(this.Intro_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private Guna.UI.WinForms.GunaGradientCircleButton gunaGradientCircleButton1;
        private Guna.UI.WinForms.GunaGradientCircleButton gunaGradientCircleButton2;
        private Guna.UI.WinForms.GunaGradientPanel gunaGradientPanel1;
    }
}